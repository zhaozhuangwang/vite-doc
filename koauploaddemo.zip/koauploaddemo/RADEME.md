## 上传demo


## 全局安装 

npm i -g koa-generator

koa2 myKoa2 

cd myKoa2

npm i 

npm start


## 上传涉及

创建新项目后增加功能的有标注  上传


备注 上传
 ./app.js

./views/index.html

./rouiter/profile.js